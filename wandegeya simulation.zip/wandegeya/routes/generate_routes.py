#!/usr/bin/env python3
"""
generate_routes.py — Wandegeya 2-lane network
  Lane 0 (kerb)   = left turn only
  Lane 1 (centre) = straight + right turn
"""
import random, argparse, xml.etree.ElementTree as ET
from xml.dom import minidom

DEMAND = {
    "low":    {"N_in":100, "S_in":90,  "W_in":80,  "E_in":70},
    "medium": {"N_in":250, "S_in":220, "W_in":180, "E_in":150},
    "peak":   {"N_in":450, "S_in":400, "W_in":300, "E_in":250},
}

# LHT destinations per origin+turn
TURNS = {
    "N_in": {"left":("E_out","0"), "straight":("S_out","1"), "right":("W_out","1")},
    "S_in": {"left":("W_out","0"), "straight":("N_out","1"), "right":("E_out","1")},
    "W_in": {"left":("N_out","0"), "straight":("E_out","1"), "right":("S_out","1")},
    "E_in": {"left":("S_out","0"), "straight":("W_out","1"), "right":("N_out","1")},
}

TURN_PROBS = [("left",0.20),("straight",0.60),("right",0.20)]
VTYPES     = [("boda_boda",0.50),("taxi_minibus",0.20),("private_car",0.25),("truck",0.05)]

def pick(choices, probs, rng):
    r=rng.random(); c=0
    for ch,p in zip(choices,probs):
        c+=p
        if r<=c: return ch
    return choices[-1]

def generate_routes(scenario="peak", duration=3600, seed=42, output_path="routes/wandegeya.rou.xml"):
    rng=random.Random(seed)
    vehicles=[]
    veh_id=0
    turns_list   = [t for t,_ in TURN_PROBS]
    turns_probs  = [p for _,p in TURN_PROBS]
    vtypes_list  = [v for v,_ in VTYPES]
    vtypes_probs = [p for _,p in VTYPES]

    for origin, vph in DEMAND[scenario].items():
        t = rng.expovariate(vph/3600.0)
        while t < duration:
            turn  = pick(turns_list, turns_probs, rng)
            vtype = pick(vtypes_list, vtypes_probs, rng)
            dest_edge, depart_lane = TURNS[origin][turn]
            vehicles.append({
                "id": f"veh_{veh_id}",
                "depart": round(t, 2),
                "type": vtype,
                "from": origin,
                "to": dest_edge,
                "departLane": depart_lane,
            })
            veh_id += 1
            t += rng.expovariate(vph/3600.0)

    vehicles.sort(key=lambda v: v["depart"])

    root = ET.Element("routes")
    root.append(ET.Comment(f" scenario={scenario} vehicles={len(vehicles)} "))
    for v in vehicles:
        el = ET.SubElement(root, "vehicle")
        el.set("id", v["id"]); el.set("type", v["type"])
        el.set("depart", str(v["depart"]))
        el.set("departLane", v["departLane"])
        el.set("departSpeed", "random")
        ET.SubElement(el, "route").set("edges", f"{v['from']} {v['to']}")

    xml_str = minidom.parseString(ET.tostring(root, encoding="unicode")).toprettyxml(indent="    ")
    with open(output_path, "w") as f:
        f.write("\n".join(l for l in xml_str.split("\n") if l.strip()))

    print(f"[{scenario}] {len(vehicles)} vehicles → {output_path}")

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--scenario", choices=["low","medium","peak"], default="peak")
    p.add_argument("--duration", type=int, default=3600)
    p.add_argument("--seed",     type=int, default=42)
    p.add_argument("--output",   default="routes/wandegeya.rou.xml")
    args = p.parse_args()
    generate_routes(args.scenario, args.duration, args.seed, args.output)
