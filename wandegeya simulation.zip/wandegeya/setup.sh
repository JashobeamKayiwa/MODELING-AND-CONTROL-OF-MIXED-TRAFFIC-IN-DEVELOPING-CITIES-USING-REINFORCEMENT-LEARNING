#!/bin/bash
# =============================================================
#  Wandegeya Traffic RL Project — Ubuntu Setup Script
#  Run this once on your machine: bash setup.sh
# =============================================================
set -e

echo "=== Step 1: Installing SUMO ==="
sudo add-apt-repository -y ppa:sumo/stable
sudo apt-get update -q
sudo apt-get install -y sumo sumo-tools sumo-doc

echo "=== Step 2: Setting SUMO_HOME ==="
echo 'export SUMO_HOME="/usr/share/sumo"' >> ~/.bashrc
echo 'export PATH="$PATH:$SUMO_HOME/tools"' >> ~/.bashrc
source ~/.bashrc
export SUMO_HOME="/usr/share/sumo"

echo "=== Step 3: Installing Python libraries ==="
pip3 install traci sumolib gymnasium numpy pandas matplotlib

echo "=== Step 4: Creating output directory ==="
mkdir -p output

echo ""
echo "✅ Setup complete! Test with:"
echo "   sumo --version"
echo "   python3 -c 'import traci; print(traci.version.VERSION)'"
