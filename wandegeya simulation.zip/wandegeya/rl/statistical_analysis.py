"""
statistical_analysis.py
════════════════════════════════════════════════════════════════
Statistical analysis of Wandegeya intersection results.

Performs:
  1. One-way ANOVA — tests whether controller differences are
     statistically significant within each scenario
  2. Tukey HSD post-hoc test — identifies which pairs differ
  3. 95% Confidence intervals for each controller/scenario
  4. Effect size (Cohen's d) between best and baseline
  5. Summary table for the report

Reference (proposal Section 3.6):
  ANOVA used to test H0: all controllers produce equal queue lengths
  α = 0.05 significance level

Usage:
    python3 rl/statistical_analysis.py

Note:
  Since we have single evaluation runs, we simulate repeated
  measurements by using per-step metrics (each step = one obs).
  This is standard practice in traffic simulation studies.
"""

import os
import sys
import csv
import math

try:
    import numpy as np
    NUMPY = True
except ImportError:
    NUMPY = False
    print("[stats] pip install numpy")
    sys.exit(1)

try:
    from scipy import stats
    from scipy.stats import f_oneway, tukey_hsd
    SCIPY = True
except ImportError:
    SCIPY = False
    print("[stats] pip install scipy")
    sys.exit(1)

try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    PLOT = True
except ImportError:
    PLOT = False

# ════════════════════════════════════════════════════════════════
#  RESULTS DATA
#  avg_queue values are per-step averages from evaluation episodes.
#  We use the raw confirmed values from training runs.
#  For ANOVA we treat each reported step value as one observation.
# ════════════════════════════════════════════════════════════════

# Per-step queue length observations from evaluation logs
# (sampled every 50 steps from the eval step output)
OBS = {
    "peak": {
        "Fixed-Time":       [15.25, 23.50, 25.88, 28.62, 30.38, 32.75, 33.62],
        "MaxPressure":      [10.25, 13.00, 14.38, 14.88, 16.50, 14.88, 14.88],
        "PressLight-DQN":   [13.50, 23.25, 25.62, 28.38, 30.38, 32.75, 34.00],
        "IntelliLight-DQN": [ 1.75,  1.88,  1.75,  1.25,  0.75,  1.00,  1.00],
    },
    "medium": {
        "Fixed-Time":       [ 8.00, 16.12, 23.88, 25.88, 27.75, 29.25, 31.12],
        "MaxPressure":      [ 7.50, 13.38, 17.38, 15.38, 13.12, 17.50, 17.50],
        "PressLight-DQN":   [ 0.00,  0.50,  0.50,  0.50,  0.75,  0.50,  0.50],
        "IntelliLight-DQN": [ 1.38,  2.12,  0.25,  2.50,  0.75,  1.50,  1.50],
    },
    "low": {
        "Fixed-Time":       [ 4.00,  7.12, 10.12, 15.00, 18.88, 22.12, 23.00],
        "MaxPressure":      [ 2.38,  4.25,  7.12, 12.00, 16.12, 15.50, 17.38],
        "PressLight-DQN":   [ 0.50,  0.62,  0.38,  0.38,  0.25,  0.00,  0.00],
        "IntelliLight-DQN": [ 0.00,  0.12,  0.38,  0.00,  0.12,  0.00,  0.00],
    },
}

CONTROLLERS = ["Fixed-Time", "MaxPressure", "PressLight-DQN", "IntelliLight-DQN"]
SCENARIOS   = ["low", "medium", "peak"]
DEMAND      = {"low": "400 veh/hr", "medium": "800 veh/hr", "peak": "1400 veh/hr"}
ALPHA       = 0.05


# ════════════════════════════════════════════════════════════════
#  HELPER FUNCTIONS
# ════════════════════════════════════════════════════════════════

def mean_ci(data, confidence=0.95):
    """Return (mean, lower_ci, upper_ci) for a list of values."""
    n    = len(data)
    mean = np.mean(data)
    se   = stats.sem(data)
    h    = se * stats.t.ppf((1 + confidence) / 2, df=n - 1)
    return mean, mean - h, mean + h


def cohens_d(group1, group2):
    """Cohen's d effect size between two groups."""
    n1, n2   = len(group1), len(group2)
    mean_diff= np.mean(group1) - np.mean(group2)
    pooled_std = math.sqrt(
        ((n1 - 1) * np.std(group1, ddof=1)**2 +
         (n2 - 1) * np.std(group2, ddof=1)**2) /
        (n1 + n2 - 2)
    )
    return mean_diff / pooled_std if pooled_std > 0 else 0.0


def effect_label(d):
    d = abs(d)
    if d < 0.2:   return "negligible"
    elif d < 0.5: return "small"
    elif d < 0.8: return "medium"
    else:         return "large"


# ════════════════════════════════════════════════════════════════
#  ANOVA
# ════════════════════════════════════════════════════════════════

def run_anova(scenario):
    groups = [np.array(OBS[scenario][c]) for c in CONTROLLERS]
    f_stat, p_val = f_oneway(*groups)
    return f_stat, p_val


# ════════════════════════════════════════════════════════════════
#  TUKEY HSD POST-HOC
# ════════════════════════════════════════════════════════════════

def run_tukey(scenario):
    groups = [np.array(OBS[scenario][c]) for c in CONTROLLERS]
    result = tukey_hsd(*groups)
    return result


# ════════════════════════════════════════════════════════════════
#  CONFIDENCE INTERVALS
# ════════════════════════════════════════════════════════════════

def compute_cis(scenario):
    cis = {}
    for ctrl in CONTROLLERS:
        data = np.array(OBS[scenario][ctrl])
        m, lo, hi = mean_ci(data)
        cis[ctrl] = (m, lo, hi)
    return cis


# ════════════════════════════════════════════════════════════════
#  PRINT REPORT
# ════════════════════════════════════════════════════════════════

def print_report():
    print("\n" + "═"*72)
    print("  STATISTICAL ANALYSIS — Wandegeya Intersection")
    print("  Metric: Average Queue Length (vehicles per step)")
    print(f"  Significance level: α = {ALPHA}")
    print("═"*72)

    all_rows = []

    for scenario in SCENARIOS:
        print(f"\n{'─'*72}")
        print(f"  {scenario.upper()} SCENARIO ({DEMAND[scenario]})")
        print(f"{'─'*72}")

        # ANOVA
        f_stat, p_val = run_anova(scenario)
        sig = "✓ SIGNIFICANT" if p_val < ALPHA else "✗ NOT significant"
        print(f"\n  One-Way ANOVA")
        print(f"    F-statistic : {f_stat:.4f}")
        print(f"    p-value     : {p_val:.4f}  →  {sig}")
        if p_val < ALPHA:
            print(f"    Interpretation: Controller type significantly affects"
                  f" queue length (p < {ALPHA})")
        else:
            print(f"    Interpretation: No significant difference detected")

        # Confidence intervals
        cis = compute_cis(scenario)
        print(f"\n  95% Confidence Intervals (Average Queue Length)")
        print(f"  {'Controller':<22} {'Mean':>7} {'95% CI Lower':>13} "
              f"{'95% CI Upper':>13} {'SD':>7}")
        print(f"  {'─'*65}")
        for ctrl in CONTROLLERS:
            data = np.array(OBS[scenario][ctrl])
            m, lo, hi = cis[ctrl]
            sd = np.std(data, ddof=1)
            print(f"  {ctrl:<22} {m:>7.2f} {lo:>13.2f} {hi:>13.2f} {sd:>7.2f}")
            all_rows.append({
                "scenario": scenario, "controller": ctrl,
                "mean": round(m,3), "ci_lower": round(lo,3),
                "ci_upper": round(hi,3), "sd": round(sd,3),
                "f_stat": round(f_stat,4), "p_value": round(p_val,4),
                "significant": p_val < ALPHA,
            })

        # Tukey HSD
        print(f"\n  Tukey HSD Post-Hoc Test (pairwise comparisons)")
        print(f"  {'Comparison':<42} {'p-adj':>8}  {'Significant':>12}")
        print(f"  {'─'*65}")
        try:
            tukey = run_tukey(scenario)
            for i, c1 in enumerate(CONTROLLERS):
                for j, c2 in enumerate(CONTROLLERS):
                    if j <= i: continue
                    p_adj = tukey.pvalue[i][j]
                    label = "✓ YES" if p_adj < ALPHA else "  no"
                    comparison = f"{c1}  vs  {c2}"
                    print(f"  {comparison:<42} {p_adj:>8.4f}  {label:>12}")
        except Exception as e:
            print(f"  [Tukey] {e}")

        # Effect sizes vs fixed-time
        ft_data = np.array(OBS[scenario]["Fixed-Time"])
        print(f"\n  Effect Size (Cohen's d) vs Fixed-Time Baseline")
        print(f"  {'Controller':<22} {'Cohen\'s d':>10} {'Magnitude':>12}")
        print(f"  {'─'*46}")
        for ctrl in CONTROLLERS[1:]:
            ctrl_data = np.array(OBS[scenario][ctrl])
            d = cohens_d(ft_data, ctrl_data)
            print(f"  {ctrl:<22} {d:>10.3f} {effect_label(d):>12}")

    return all_rows


# ════════════════════════════════════════════════════════════════
#  CONFIDENCE INTERVAL PLOT
# ════════════════════════════════════════════════════════════════

def plot_ci():
    if not PLOT: return

    fig, axes = plt.subplots(1, 3, figsize=(15, 5), sharey=False)
    fig.suptitle("95% Confidence Intervals — Average Queue Length\n"
                 "Wandegeya Intersection, Kampala",
                 fontsize=13, fontweight="bold")

    colors = {
        "Fixed-Time":       "#64748b",
        "MaxPressure":      "#22c55e",
        "PressLight-DQN":   "#f97316",
        "IntelliLight-DQN": "#6366f1",
    }

    for ax, scenario in zip(axes, SCENARIOS):
        cis   = compute_cis(scenario)
        names = CONTROLLERS
        means = [cis[c][0] for c in names]
        lows  = [cis[c][1] for c in names]
        highs = [cis[c][2] for c in names]
        errs  = [[m - l for m, l in zip(means, lows)],
                 [h - m for m, h in zip(means, highs)]]
        clrs  = [colors[c] for c in names]

        ax.bar(names, means, color=clrs, alpha=0.8,
               edgecolor="white", linewidth=1.2)
        ax.errorbar(names, means, yerr=errs, fmt='none',
                    color='black', capsize=5, linewidth=1.5)

        f_stat, p_val = run_anova(scenario)
        sig_str = f"ANOVA: F={f_stat:.2f}, p={p_val:.4f}"
        ax.set_title(f"{scenario.upper()} ({DEMAND[scenario]})\n{sig_str}",
                     fontsize=10, fontweight="bold")
        ax.set_ylabel("Avg Queue Length (vehicles)", fontsize=9)
        ax.set_xticklabels(names, rotation=15, ha="right", fontsize=8)
        ax.grid(True, axis="y", alpha=0.3)

        # Mark significance
        if p_val < ALPHA:
            ax.text(0.98, 0.98, "p < 0.05\n✓ Significant",
                    transform=ax.transAxes, ha="right", va="top",
                    fontsize=8, color="green",
                    bbox=dict(boxstyle="round", facecolor="lightgreen", alpha=0.3))

    plt.tight_layout()
    os.makedirs("output", exist_ok=True)
    path = "output/confidence_intervals.png"
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"\n  Saved → {path}")


# ════════════════════════════════════════════════════════════════
#  SAVE CSV
# ════════════════════════════════════════════════════════════════

def save_stats_csv(rows):
    os.makedirs("output", exist_ok=True)
    path = "output/statistical_analysis.csv"
    fields = ["scenario","controller","mean","ci_lower","ci_upper",
              "sd","f_stat","p_value","significant"]
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)
    print(f"  Saved → {path}")


# ════════════════════════════════════════════════════════════════
#  MAIN
# ════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    rows = print_report()

    print("\n\n  Generating confidence interval chart...")
    plot_ci()

    save_stats_csv(rows)

    print("\n  Files:")
    print("    output/confidence_intervals.png")
    print("    output/statistical_analysis.csv")
    print("\n  Done.")
