"""
test_env.py
════════════════════════════════════════════════════════
Quick sanity check for the WandegeyaEnv:
  - Resets the environment
  - Runs 10 random-action steps
  - Prints observation, reward, and vehicle type counts each step
  - Confirms TraCI connects and disconnects cleanly

Run from the wandegeya/ folder:
    python3 rl/test_env.py
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from wandegeya_env import WandegeyaEnv

def main():
    print("=" * 60)
    print("  Wandegeya RL Environment — Sanity Test")
    print("=" * 60)

    env = WandegeyaEnv(scenario="peak", gui=False)

    print("\n[1] Resetting environment...")
    obs, info = env.reset()
    print(f"    Observation shape : {obs.shape}")
    print(f"    Observation sample: {obs[:8].round(3)}  (queue lengths)")
    print(f"    Action space      : {env.action_space}")

    print("\n[2] Running 10 random steps...\n")
    total_reward = 0.0

    for step in range(10):
        action = env.action_space.sample()
        obs, reward, terminated, truncated, info = env.step(action)
        total_reward += reward

        counts = env.get_vehicle_type_counts()
        queues = env.get_queue_lengths()

        print(f"  Step {step+1:2d} | action={action} | reward={reward:10.1f}")
        print(f"           queues : { {k.split('_')[0]+'_'+k.split('_')[2]: v for k,v in queues.items()} }")
        print(f"           types  : boda={counts['boda_boda']} taxi={counts['taxi_minibus']} "
              f"car={counts['private_car']} truck={counts['truck']} "
              f"amb={counts['ambulance']} convoy={counts['convoy_lead']+counts['convoy_follow']}")
        print(f"           sim_step={info['step']}  vehicles_active={info['vehicles_running']}")
        print()

        if terminated:
            print("  Episode finished early.")
            break

    print(f"[3] Total reward over 10 steps: {total_reward:.1f}")
    print("\n[4] Closing environment...")
    env.close()
    print("    Done. TraCI closed cleanly.")
    print("=" * 60)

if __name__ == "__main__":
    main()
