"""
analyse_results.py
════════════════════════════════════════════════════════════════
Results comparison and chart generation for Wandegeya project.

After each scenario run, fill in the RESULTS dict below,
then re-run: python3 rl/analyse_results.py

Usage:
    python3 rl/analyse_results.py
"""

import os, sys, csv
from datetime import datetime

try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    PLOT = True
except ImportError:
    PLOT = False
    print("[analyse] pip install matplotlib for charts")

# ════════════════════════════════════════════════════════════════
#  RESULTS — fill in avg_queue, avg_wait, throughput after each run
#  avg_wait = per-step average total waiting time (from training log)
# ════════════════════════════════════════════════════════════════

RESULTS = {
    "peak": [
        {"controller": "Fixed-Time",       "avg_queue": 25.23, "avg_wait": 858.8,  "throughput": 60},
        {"controller": "MaxPressure",      "avg_queue": 13.18, "avg_wait": 240.1,  "throughput": 92},
        {"controller": "PressLight-DQN",   "avg_queue": 24.75, "avg_wait": 814.0,  "throughput": 54},
        {"controller": "IntelliLight-DQN", "avg_queue":  0.99, "avg_wait":   0.50, "throughput": 101},
    ],
    "medium": [
        {"controller": "Fixed-Time",       "avg_queue": 21.45, "avg_wait": 680.2,  "throughput": 17},
        {"controller": "MaxPressure",      "avg_queue": 12.59, "avg_wait": 216.2,  "throughput": 49},
        {"controller": "PressLight-DQN",   "avg_queue":  0.55, "avg_wait":   0.39, "throughput": 56},
        {"controller": "IntelliLight-DQN", "avg_queue":  0.96, "avg_wait":   0.79, "throughput": 68},
    ],
    "low": [
        {"controller": "Fixed-Time",       "avg_queue": 13.04, "avg_wait": 364.3,  "throughput": 9},
        {"controller": "MaxPressure",      "avg_queue":  9.29, "avg_wait": 153.2,  "throughput": 19},
        {"controller": "PressLight-DQN",   "avg_queue":  0.26, "avg_wait":   0.28, "throughput": 20},
        {"controller": "IntelliLight-DQN", "avg_queue":  0.17, "avg_wait":   0.10, "throughput": 18},
    ],
}

# Learning curves — peak scenario confirmed runs
IL_REWARDS = [
    -374.9, -208.8, -37.5, -59.6, -68.6, -14.6, -7.2, -71.8,
    -21.9,  -26.9,  -64.0, -49.3, -41.5, -56.2, -29.9, -25.0,
    -18.2,  -30.0,    7.3,   9.4,  -0.2,  11.6, -87.2,  -9.1,
    -33.4,  -15.0,   -0.5,  -5.0,   7.4,  16.5
]
PL_REWARDS = [
    -117.8, -189.7, -154.9, -234.3, -162.5, -269.0, -189.1, -496.6,
    -471.5, -479.2, -365.4, -445.3, -578.8, -231.6, -200.1, -211.4,
    -280.3, -202.1, -153.9, -122.3, -212.1, -251.6, -215.0, -214.9,
    -100.5, -373.7, -235.6,  -81.7,  -72.5, -202.4
]

CONTROLLERS = ["Fixed-Time", "MaxPressure", "PressLight-DQN", "IntelliLight-DQN"]
SCENARIOS   = ["low", "medium", "peak"]
COLORS      = {
    "Fixed-Time":       "#64748b",
    "MaxPressure":      "#22c55e",
    "PressLight-DQN":   "#f97316",
    "IntelliLight-DQN": "#6366f1",
}
DEMAND = {"low": "400 veh/hr", "medium": "800 veh/hr", "peak": "1400 veh/hr"}


def has_data(scenario):
    return all(r["avg_queue"] is not None for r in RESULTS.get(scenario, []))


def pct(baseline, value):
    if None in (baseline, value) or baseline == 0:
        return None
    return (baseline - value) / baseline * 100


def rolling(data, w=5):
    return [sum(data[max(0, i-w):i+1]) / len(data[max(0, i-w):i+1])
            for i in range(len(data))]


# ── Console table ─────────────────────────────────────────────
def print_table():
    for sc in SCENARIOS:
        if not has_data(sc):
            print(f"\n  [{sc.upper()}] — awaiting data")
            continue
        rows = RESULTS[sc]
        bq   = rows[0]["avg_queue"]
        bw   = rows[0]["avg_wait"]
        print(f"\n{'═'*72}")
        print(f"  {sc.upper()} SCENARIO  ({DEMAND[sc]})")
        print(f"{'═'*72}")
        print(f"  {'Controller':<22} {'AvgQueue':>9} {'AvgWait':>10} "
              f"{'Throughput':>11} {'ΔQueue':>8} {'ΔWait':>8}")
        print(f"  {'─'*70}")
        for r in rows:
            dq = pct(bq, r["avg_queue"]); dw = pct(bw, r["avg_wait"])
            print(f"  {r['controller']:<22} {r['avg_queue']:>9.2f} "
                  f"{r['avg_wait']:>10.1f} {r['throughput']:>11} "
                  f"{'—':>8}" if dq is None else
                  f"  {r['controller']:<22} {r['avg_queue']:>9.2f} "
                  f"{r['avg_wait']:>10.1f} {r['throughput']:>11} "
                  f"{dq:>+7.1f}% {dw:>+7.1f}%")


# ── Learning curves ───────────────────────────────────────────
def plot_learning_curves():
    if not PLOT: return
    fig, ax = plt.subplots(figsize=(11, 5))
    eps = list(range(1, 31))

    for data, label, color in [
        (PL_REWARDS, "PressLight-DQN",   COLORS["PressLight-DQN"]),
        (IL_REWARDS, "IntelliLight-DQN", COLORS["IntelliLight-DQN"]),
    ]:
        ax.plot(eps, data,         color=color, linewidth=1.0, alpha=0.4)
        ax.plot(eps, rolling(data),color=color, linewidth=2.5,
                linestyle="--", label=f"{label} (5-ep trend)")

    ax.fill_between(eps, IL_REWARDS, 0,
                    where=[r > 0 for r in IL_REWARDS],
                    alpha=0.12, color=COLORS["IntelliLight-DQN"])
    ax.axhline(0, color="gray", linestyle=":", linewidth=1, alpha=0.6)
    ax.set_xlabel("Episode", fontsize=12)
    ax.set_ylabel("Cumulative Reward", fontsize=12)
    ax.set_title("Training Learning Curves — Peak Scenario (1400 veh/hr)",
                 fontsize=13, fontweight="bold")
    ax.legend(fontsize=10)
    ax.grid(True, alpha=0.2)
    ax.set_xlim(1, 30)
    plt.tight_layout()
    path = "output/learning_curves.png"
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  Saved → {path}")


# ── Per-metric bar charts (one bar group per scenario) ────────
def plot_metric_bars(metric_key, ylabel, fname):
    if not PLOT: return
    available = [s for s in SCENARIOS if has_data(s)]
    if not available: return

    fig, ax = plt.subplots(figsize=(10, 5))
    n_ctrl = len(CONTROLLERS)
    n_sc   = len(available)
    width  = 0.8 / n_sc
    x      = range(n_ctrl)

    sc_colors = {"low": "#86efac", "medium": "#4ade80", "peak": "#16a34a"}

    for i, sc in enumerate(available):
        rows   = RESULTS[sc]
        vals   = [next(r[metric_key] for r in rows if r["controller"] == c)
                  for c in CONTROLLERS]
        offset = (i - n_sc / 2 + 0.5) * width
        bars   = ax.bar([xi + offset for xi in x], vals, width,
                        label=f"{sc.upper()} ({DEMAND[sc]})",
                        color=sc_colors[sc], alpha=0.85, edgecolor="white")
        for bar, val in zip(bars, vals):
            if val is not None:
                ax.text(bar.get_x() + bar.get_width()/2,
                        bar.get_height() * 1.01,
                        f"{val:.1f}", ha="center", va="bottom",
                        fontsize=7, fontweight="bold")

    ax.set_xticks(list(x))
    ax.set_xticklabels(CONTROLLERS, fontsize=9, rotation=10, ha="right")
    ax.set_ylabel(ylabel, fontsize=11)
    ax.set_title(f"{ylabel} by Controller and Scenario — Wandegeya Intersection",
                 fontsize=12, fontweight="bold")
    ax.legend(fontsize=9)
    ax.grid(True, axis="y", alpha=0.25)
    plt.tight_layout()
    path = f"output/{fname}"
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  Saved → {path}")


# ── Improvement over fixed-time ───────────────────────────────
def plot_improvement():
    if not PLOT: return
    available = [s for s in SCENARIOS if has_data(s)]
    if not available: return

    rl = ["MaxPressure", "PressLight-DQN", "IntelliLight-DQN"]
    fig, axes = plt.subplots(1, 2, figsize=(13, 5))
    fig.suptitle("Improvement over Fixed-Time Baseline — Wandegeya Intersection",
                 fontsize=13, fontweight="bold")

    sc_colors = {"low": "#86efac", "medium": "#4ade80", "peak": "#16a34a"}
    n_sc  = len(available)
    width = 0.8 / n_sc
    x     = range(len(rl))

    for ax, metric_key, ylabel in zip(
        axes,
        ["avg_queue", "avg_wait"],
        ["Queue Reduction (%)", "Wait Reduction (%)"]
    ):
        for i, sc in enumerate(available):
            rows    = RESULTS[sc]
            baseline= rows[0][metric_key]
            imps    = [pct(baseline, next(r[metric_key] for r in rows
                                          if r["controller"] == c)) or 0
                       for c in rl]
            offset  = (i - n_sc/2 + 0.5) * width
            bars    = ax.bar([xi + offset for xi in x], imps, width,
                             label=f"{sc.upper()} ({DEMAND[sc]})",
                             color=sc_colors[sc], alpha=0.85, edgecolor="white")
            for bar, val in zip(bars, imps):
                ax.text(bar.get_x() + bar.get_width()/2,
                        bar.get_height() + 0.5,
                        f"{val:.1f}%", ha="center", va="bottom",
                        fontsize=7, fontweight="bold")

        ax.set_xticks(list(x))
        ax.set_xticklabels(rl, fontsize=9)
        ax.set_ylabel(ylabel, fontsize=11)
        ax.axhline(0, color="black", linewidth=0.8)
        ax.grid(True, axis="y", alpha=0.25)
        ax.legend(fontsize=8)

    plt.tight_layout()
    path = "output/improvement.png"
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  Saved → {path}")


# ── CSV export ────────────────────────────────────────────────
def save_csv():
    os.makedirs("output", exist_ok=True)
    path = "output/full_results.csv"
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=[
            "scenario","controller","avg_queue","avg_wait",
            "throughput","delta_queue_pct","delta_wait_pct"
        ])
        w.writeheader()
        for sc in SCENARIOS:
            if not has_data(sc): continue
            rows = RESULTS[sc]; baseline = rows[0]
            for r in rows:
                dq = pct(baseline["avg_queue"], r["avg_queue"])
                dw = pct(baseline["avg_wait"],  r["avg_wait"])
                w.writerow({
                    "scenario":        sc,
                    "controller":      r["controller"],
                    "avg_queue":       r["avg_queue"],
                    "avg_wait":        r["avg_wait"],
                    "throughput":      r["throughput"],
                    "delta_queue_pct": round(dq,2) if dq is not None else "",
                    "delta_wait_pct":  round(dw,2) if dw is not None else "",
                })
    print(f"  Saved → {path}")


# ════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    os.makedirs("output", exist_ok=True)
    print("\n  Wandegeya Intersection — Results Analysis")

    print_table()

    if PLOT:
        print("\n  Generating charts...")
        plot_learning_curves()
        plot_metric_bars("avg_queue",  "Average Queue Length (vehicles)", "queue_comparison.png")
        plot_metric_bars("avg_wait",   "Average Wait Time (s/step)",      "wait_comparison.png")
        plot_metric_bars("throughput", "Total Throughput (vehicles)",     "throughput_comparison.png")
        plot_improvement()

    save_csv()
    print("\n  Done.")