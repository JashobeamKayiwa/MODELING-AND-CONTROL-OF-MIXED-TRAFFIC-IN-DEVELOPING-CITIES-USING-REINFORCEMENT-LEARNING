"""
wandegeya_env.py
════════════════════════════════════════════════════════════════
Gymnasium-compatible RL environment for Wandegeya intersection.
Uses SUMO TraCI to control traffic signals step by step.

State space:
  - Queue length per lane (8 lanes: N0,N1,S0,S1,W0,W1,E0,E1)
  - Current phase index (0-7)
  - Time elapsed in current phase (normalised)
  - Presence of priority vehicle within 50m of junction

Action space:
  - Discrete(8): select which phase to activate next

Reward:
  - Negative total waiting time across all vehicles per step
  - Bonus for clearing priority vehicles quickly

Reference: PressLight / IntelliLight pattern (Wei et al. 2019, 2018)
"""

import os
import sys
import gymnasium as gym
import numpy as np

# ── Locate SUMO tools ────────────────────────────────────────
if "SUMO_HOME" in os.environ:
    sys.path.append(os.path.join(os.environ["SUMO_HOME"], "tools"))
else:
    sys.path.append("/usr/share/sumo/tools")

import traci
import traci.constants as tc

# ── Constants ────────────────────────────────────────────────
SUMO_BINARY   = "sumo"          # use "sumo-gui" to watch visually
NET_FILE      = "network/wandegeya.net.xml"
ROUTE_FILE    = "routes/wandegeya_peak_merged.rou.xml"
ADDITIONAL    = "routes/vehicle_types.add.xml,network/detectors.add.xml"
TL_ID         = "J"
STEP_LENGTH   = 1               # simulation seconds per step
YELLOW_DUR    = 3               # yellow phase duration (seconds)
MIN_GREEN     = 10              # minimum green duration (seconds)
MAX_GREEN     = 60              # maximum green duration (seconds)
SIM_DURATION  = 3600            # 1 hour per episode

# Phase index mapping (matches tlLogic baseline_8phase)
PHASE_GREEN  = [0, 2, 4, 6]    # green phase indices
PHASE_YELLOW = [1, 3, 5, 7]    # yellow phase indices

# Inbound lanes for state extraction
INBOUND_LANES = [
    "N_in_0", "N_in_1",
    "S_in_0", "S_in_1",
    "W_in_0", "W_in_1",
    "E_in_0", "E_in_1",
]

# Priority vehicle types
PRIORITY_TYPES = {"ambulance", "convoy_lead", "convoy_follow"}

# Max queue length for normalisation (vehicles)
MAX_QUEUE = 30.0


class WandegeyaEnv(gym.Env):
    """
    Gymnasium environment for RL-based traffic signal control
    at the Wandegeya intersection, Kampala.

    Observation (20-dim vector):
        [0:8]   queue length per inbound lane (normalised 0-1)
        [8:16]  waiting time per inbound lane (normalised 0-1)
        [16]    current green phase index (normalised 0-1)
        [17]    time in current phase (normalised 0-1)
        [18]    priority vehicle present N/S arms (0 or 1)
        [19]    priority vehicle present E/W arms (0 or 1)

    Action:
        Integer 0-3 → select which green phase to switch to next
        (0=N, 1=S, 2=W, 3=E — agent picks the next arm to serve)

    Reward:
        - sum of per-vehicle waiting time (negative, minimise)
        - priority vehicle bonus: -50 per priority vehicle waiting
    """

    metadata = {"render_modes": ["human"]}

    def __init__(self, scenario="peak", gui=False, seed=42):
        super().__init__()

        self.scenario   = scenario
        self.gui        = gui
        self.seed_val   = seed
        self.sumo_binary = "sumo-gui" if gui else SUMO_BINARY

        # Route file selection
        self.route_file = f"routes/wandegeya_{scenario}_merged.rou.xml"

        # Gymnasium spaces
        self.observation_space = gym.spaces.Box(
            low=0.0, high=1.0,
            shape=(20,), dtype=np.float32
        )
        # 4 actions: switch to N / S / W / E green phase
        self.action_space = gym.spaces.Discrete(4)

        # Internal state
        self._sumo_running  = False
        self._step_count    = 0
        self._current_phase = 0   # current green phase arm index (0-3)
        self._phase_timer   = 0   # seconds spent in current phase
        self._total_reward  = 0.0

        # Action → SUMO phase index mapping
        # Each action selects a green phase; yellow follows automatically
        self._action_to_phase = {
            0: 0,   # N green  (phase 0 in tlLogic)
            1: 4,   # S green  (phase 4)
            2: 2,   # W green  (phase 2)
            3: 6,   # E green  (phase 6)
        }

    # ── SUMO lifecycle ───────────────────────────────────────

    def _start_sumo(self):
        """Launch SUMO and connect TraCI."""
        cmd = [
            self.sumo_binary,
            "-n", NET_FILE,
            "-r", self.route_file,
            "-a", ADDITIONAL,
            "--step-length",             str(STEP_LENGTH),
            "--time-to-teleport",        "-1",    # vehicles wait, never teleport
            "--lateral-resolution",      "0.8",   # sublane model (boda bodas)
            "--collision.action",        "warn",  # log only, no removal
            "--collision.mingap-factor", "0",     # ignore minGap collisions
            "--ignore-route-errors",              # don't abort on route issues
            "--no-step-log",
            "--seed", str(self.seed_val),
            "--quit-on-end",
        ]
        traci.start(cmd)
        self._sumo_running = True

    def _stop_sumo(self):
        """Close TraCI connection."""
        if self._sumo_running:
            traci.close()
            self._sumo_running = False

    # ── Core Gymnasium methods ───────────────────────────────

    def reset(self, seed=None, options=None):
        """Start a new episode."""
        self._stop_sumo()
        self._start_sumo()

        self._step_count    = 0
        self._current_phase = 0
        self._phase_timer   = 0
        self._total_reward  = 0.0

        # Set initial phase
        traci.trafficlight.setPhase(TL_ID, self._action_to_phase[0])

        obs = self._get_observation()
        info = {}
        return obs, info

    def step(self, action):
        """
        Execute one RL step:
          1. If action differs from current phase, insert yellow then switch.
          2. Simulate MIN_GREEN seconds.
          3. Return observation, reward, done, info.
        """
        assert self.action_space.contains(action), f"Invalid action: {action}"

        target_phase = self._action_to_phase[action]
        current_sumo_phase = traci.trafficlight.getPhase(TL_ID)

        # Insert yellow transition if switching to a different arm
        if target_phase != current_sumo_phase and current_sumo_phase in PHASE_GREEN:
            yellow_phase = current_sumo_phase + 1
            traci.trafficlight.setPhase(TL_ID, yellow_phase)
            for _ in range(YELLOW_DUR):
                traci.simulationStep()
                self._step_count += 1

        # Set the new green phase
        traci.trafficlight.setPhase(TL_ID, target_phase)
        self._current_phase = action
        self._phase_timer   = 0

        # Simulate MIN_GREEN steps and accumulate reward
        step_reward = 0.0
        for _ in range(MIN_GREEN):
            traci.simulationStep()
            self._step_count += 1
            self._phase_timer += 1
            step_reward += self._compute_reward()

        obs  = self._get_observation()
        done = self._step_count * STEP_LENGTH >= SIM_DURATION
        self._total_reward += step_reward

        info = {
            "step":          self._step_count,
            "phase":         self._current_phase,
            "total_reward":  self._total_reward,
            "vehicles_running": traci.simulation.getMinExpectedNumber(),
        }

        return obs, step_reward, done, False, info

    def close(self):
        self._stop_sumo()

    # ── State extraction ─────────────────────────────────────

    def _get_observation(self):
        """
        Build the 20-dim observation vector from TraCI queries.
        """
        obs = np.zeros(20, dtype=np.float32)

        # [0:8] Queue length per lane (halting vehicles)
        for i, lane in enumerate(INBOUND_LANES):
            q = traci.lane.getLastStepHaltingNumber(lane)
            obs[i] = min(q / MAX_QUEUE, 1.0)

        # [8:16] Mean waiting time per lane (seconds, normalised by 120s)
        for i, lane in enumerate(INBOUND_LANES):
            w = traci.lane.getWaitingTime(lane)
            obs[8 + i] = min(w / 120.0, 1.0)

        # [16] Current phase (normalised)
        obs[16] = self._current_phase / 3.0

        # [17] Time in phase (normalised by MAX_GREEN)
        obs[17] = min(self._phase_timer / MAX_GREEN, 1.0)

        # [18] Priority vehicle on N/S arms
        obs[18] = self._priority_vehicle_present(["N_in_0","N_in_1","S_in_0","S_in_1"])

        # [19] Priority vehicle on E/W arms
        obs[19] = self._priority_vehicle_present(["W_in_0","W_in_1","E_in_0","E_in_1"])

        return obs

    def _priority_vehicle_present(self, lanes):
        """Return 1.0 if any priority vehicle is within 50m of junction."""
        for lane in lanes:
            vehs = traci.lane.getLastStepVehicleIDs(lane)
            for veh in vehs:
                if traci.vehicle.getTypeID(veh) in PRIORITY_TYPES:
                    dist = traci.lane.getLength(lane) - traci.vehicle.getLanePosition(veh)
                    if dist <= 50.0:
                        return 1.0
        return 0.0

    # ── Reward ───────────────────────────────────────────────

    def _compute_reward(self):
        """
        Reward = negative total waiting time across all vehicles.
        Priority penalty: -50 per priority vehicle currently waiting.
        """
        total_wait = 0.0
        priority_penalty = 0.0

        for veh in traci.vehicle.getIDList():
            wait = traci.vehicle.getWaitingTime(veh)
            total_wait += wait
            if traci.vehicle.getTypeID(veh) in PRIORITY_TYPES and wait > 0:
                priority_penalty += 50.0

        reward = -(total_wait + priority_penalty)
        return reward

    # ── Helpers ──────────────────────────────────────────────

    def get_vehicle_type_counts(self):
        """
        Returns a dict of {vehicle_type: count} for all active vehicles.
        Useful for live monitoring during training.
        """
        counts = {
            "boda_boda":    0,
            "taxi_minibus": 0,
            "private_car":  0,
            "truck":        0,
            "ambulance":    0,
            "convoy_lead":  0,
            "convoy_follow":0,
        }
        for veh in traci.vehicle.getIDList():
            vtype = traci.vehicle.getTypeID(veh)
            if vtype in counts:
                counts[vtype] += 1
        return counts

    def get_queue_lengths(self):
        """Returns dict of {lane_id: queue_length} for all inbound lanes."""
        return {
            lane: traci.lane.getLastStepHaltingNumber(lane)
            for lane in INBOUND_LANES
        }