"""
presslight.py
════════════════════════════════════════════════════════════════
Faithful implementation of PressLight for Wandegeya Intersection.

Reference:
  Wei, H., Zheng, G., Gayah, V., & Li, Z. (2019).
  PressLight: Learning Max Pressure Control to Coordinate
  Traffic Signals in Arterial Network.
  KDD 2019. DOI: 10.1145/3292500.3330949

Key definitions from the paper:
─────────────────────────────────────────────────────────────
  Movement m: a (inbound_lane, outbound_lane) pair
  
  Pressure of movement m:
    p(m) = n(inbound_lane) / cap(inbound_lane)
           - n(outbound_lane) / cap(outbound_lane)
    where n() = vehicle count, cap() = lane capacity

  Phase pressure:
    P(phase) = sum of |p(m)| for all movements m in phase

  Max-pressure action:
    a* = argmax P(phase)

  Reward (per paper, Eq. 5):
    r = -P(current_phase)   [negative pressure of chosen phase]

  State (per paper):
    Vector of movement-level pressures for all movements
    at the intersection → directly feeds DQN

  DQN:
    Input:  movement pressure vector
    Output: Q-value for each phase
    Target: r + γ * max Q(s', a')
─────────────────────────────────────────────────────────────
"""

import os
import sys
import random
import numpy as np
from collections import deque

try:
    import torch
    import torch.nn as nn
    import torch.optim as optim
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False
    print("[PressLight] torch not found — DQN agent unavailable. "
          "Install with: pip install torch")

# ════════════════════════════════════════════════════════════════
#  MOVEMENT DEFINITIONS
#  Each movement = (inbound_lane, outbound_lane)
#  Derived directly from the connections in wandegeya.net.xml
#  Duplicate toLane connections are collapsed to unique movements
# ════════════════════════════════════════════════════════════════

# Unique movements: (inbound_lane, outbound_edge)
# We use edge-level outbound (aggregated across lanes) as per paper
MOVEMENTS = [
    # ID  inbound_lane   outbound_lane   direction  arm
    ( 0, "N_in_0",      "E_out_0",      "l",       "N"),  # N left
    ( 1, "N_in_1",      "S_out_0",      "s",       "N"),  # N straight
    ( 2, "N_in_1",      "W_out_0",      "r",       "N"),  # N right
    ( 3, "S_in_0",      "W_out_0",      "l",       "S"),  # S left
    ( 4, "S_in_1",      "N_out_0",      "s",       "S"),  # S straight
    ( 5, "S_in_1",      "E_out_0",      "r",       "S"),  # S right
    ( 6, "W_in_0",      "N_out_0",      "l",       "W"),  # W left
    ( 7, "W_in_1",      "E_out_0",      "s",       "W"),  # W straight
    ( 8, "W_in_1",      "S_out_0",      "r",       "W"),  # W right
    ( 9, "E_in_0",      "S_out_0",      "l",       "E"),  # E left
    (10, "E_in_1",      "W_out_0",      "s",       "E"),  # E straight
    (11, "E_in_1",      "N_out_0",      "r",       "E"),  # E right
]
N_MOVEMENTS = len(MOVEMENTS)  # 12

# Phase → movement indices (which movements are active in each phase)
# Matches tlLogic phases in wandegeya.net.xml
# Phase 0 (N green + W left): N movements (0,1,2) + W left (6)
# Phase 1 (S green + E left): S movements (3,4,5) + E left (9)
# Phase 2 (W green + S left): W movements (6,7,8) + S left (3)
# Phase 3 (E green + N left): E movements (9,10,11) + N left (0)
PHASE_MOVEMENTS = {
    0: [0, 1, 2, 6],    # N green + W left
    1: [3, 4, 5, 9],    # S green + E left
    2: [6, 7, 8, 3],    # W green + S left
    3: [9, 10, 11, 0],  # E green + N left
}
N_PHASES = 4

# Lane capacities (vehicles) — based on lane length / avg vehicle spacing
# length=294m, avg spacing ~7m (vehicle + gap) → ~42 vehicles per lane
LANE_CAPACITY = {
    "N_in_0": 42,  "N_in_1": 42,
    "S_in_0": 42,  "S_in_1": 42,
    "W_in_0": 42,  "W_in_1": 42,
    "E_in_0": 42,  "E_in_1": 42,
    "N_out_0": 42, "N_out_1": 42,
    "S_out_0": 42, "S_out_1": 42,
    "W_out_0": 42, "W_out_1": 42,
    "E_out_0": 42, "E_out_1": 42,
}

PRIORITY_TYPES = {"ambulance", "convoy_lead", "convoy_follow"}


# ════════════════════════════════════════════════════════════════
#  PRESSURE COMPUTATION  (paper Section 3.2)
# ════════════════════════════════════════════════════════════════

def get_lane_density(traci, lane_id):
    """
    Normalised vehicle density on a lane.
    density = vehicle_count / capacity  ∈ [0, 1]
    Priority vehicles count as 2 (higher urgency).
    """
    vehs = traci.lane.getLastStepVehicleIDs(lane_id)
    count = 0
    for v in vehs:
        count += 2 if traci.vehicle.getTypeID(v) in PRIORITY_TYPES else 1
    cap = LANE_CAPACITY.get(lane_id, 42)
    return min(count / cap, 1.0)


def compute_movement_pressure(traci, movement):
    """
    p(m) = density(inbound) - density(outbound)
    Per paper Eq. (2): normalised difference.
    """
    _, in_lane, out_lane, _, _ = movement
    p = get_lane_density(traci, in_lane) - get_lane_density(traci, out_lane)
    return p


def compute_all_pressures(traci):
    """
    Returns np.array of shape (N_MOVEMENTS,) — one pressure per movement.
    This is the state vector fed to the DQN (paper Section 3.3).
    """
    pressures = np.zeros(N_MOVEMENTS, dtype=np.float32)
    for m in MOVEMENTS:
        pressures[m[0]] = compute_movement_pressure(traci, m)
    return pressures


def compute_phase_pressure(traci, phase_idx):
    """
    P(phase) = sum of |p(m)| for movements m in phase
    Per paper Eq. (3).
    """
    total = 0.0
    for m_idx in PHASE_MOVEMENTS[phase_idx]:
        m = MOVEMENTS[m_idx]
        total += abs(compute_movement_pressure(traci, m))
    return total


# ════════════════════════════════════════════════════════════════
#  PressLightAgent — pure max-pressure (no learning)
#  Implements the analytical max-pressure policy from the paper.
#  Acts as a strong deterministic baseline above fixed-time.
# ════════════════════════════════════════════════════════════════

class PressLightAgent:
    """
    Deterministic max-pressure controller (paper Algorithm 1).
    At each decision step: a* = argmax_phase P(phase)
    No neural network — exact analytical solution.
    """

    def __init__(self):
        self.name = "PressLight-MaxPressure"
        self.last_pressures = {}

    def select_action(self, traci):
        """
        Select phase with maximum pressure.
        Returns action ∈ {0, 1, 2, 3}.
        """
        pressures = {
            phase: compute_phase_pressure(traci, phase)
            for phase in range(N_PHASES)
        }
        self.last_pressures = pressures
        return max(pressures, key=pressures.get)

    def get_state(self, traci):
        """Movement-level pressure vector (for logging/comparison)."""
        return compute_all_pressures(traci)

    def compute_reward(self, traci, action):
        """
        r = -P(current_phase)
        Per paper Eq. (5): penalise pressure of the phase just executed.
        """
        return -compute_phase_pressure(traci, action)


# ════════════════════════════════════════════════════════════════
#  DQN Network  (paper Section 3.3)
# ════════════════════════════════════════════════════════════════

if TORCH_AVAILABLE:
    class PressLightNetwork(nn.Module):
        """
        DQN for PressLight (paper Fig. 3).
        Input:  movement pressure vector (N_MOVEMENTS = 12 dims)
        Output: Q-value for each phase (N_PHASES = 4)

        Architecture matches paper: fully connected layers
        with ReLU activations.
        """

        def __init__(self, input_dim=N_MOVEMENTS, hidden_dim=20,
                     output_dim=N_PHASES):
            super().__init__()
            # Compact network per paper — pressure state is small
            self.net = nn.Sequential(
                nn.Linear(input_dim, hidden_dim),
                nn.ReLU(),
                nn.Linear(hidden_dim, hidden_dim),
                nn.ReLU(),
                nn.Linear(hidden_dim, output_dim),
            )

        def forward(self, x):
            return self.net(x)


# ════════════════════════════════════════════════════════════════
#  PressLightDQNAgent  (paper Section 3.3 + Algorithm 2)
# ════════════════════════════════════════════════════════════════

class PressLightDQNAgent:
    """
    PressLight DQN agent (faithful to the paper).

    State  : movement pressure vector  shape=(12,)
    Action : phase index ∈ {0,1,2,3}
    Reward : -P(executed_phase)

    Training follows standard DQN with experience replay
    and a target network (paper Section 3.3).
    """

    def __init__(
        self,
        lr            = 1e-3,
        gamma         = 0.95,
        epsilon       = 1.0,
        epsilon_min   = 0.05,
        epsilon_decay = 0.9995,
        batch_size    = 32,
        memory_size   = 3000,
        target_update = 20,
    ):
        if not TORCH_AVAILABLE:
            raise ImportError("torch required. pip install torch")

        self.name          = "PressLight-DQN"
        self.gamma         = gamma
        self.epsilon       = epsilon
        self.epsilon_min   = epsilon_min
        self.epsilon_decay = epsilon_decay
        self.batch_size    = batch_size
        self.target_update = target_update
        self.steps         = 0

        self.memory = deque(maxlen=memory_size)

        self.policy_net = PressLightNetwork()
        self.target_net = PressLightNetwork()
        self.target_net.load_state_dict(self.policy_net.state_dict())
        self.target_net.eval()

        self.optimizer = optim.RMSprop(
            self.policy_net.parameters(), lr=lr
        )
        self.loss_fn = nn.MSELoss()

    def get_state(self, traci):
        """
        State = movement pressure vector.
        Shape: (N_MOVEMENTS,) = (12,)
        Per paper: s_t = [p(m) for m in all_movements]
        """
        return compute_all_pressures(traci)

    def compute_reward(self, traci, action):
        """
        r = -P(phase)  per paper Eq. (5)
        Negative pressure of the executed phase.
        """
        reward = -compute_phase_pressure(traci, action)

        # Priority vehicle penalty
        for veh in traci.vehicle.getIDList():
            if (traci.vehicle.getTypeID(veh) in PRIORITY_TYPES
                    and traci.vehicle.getWaitingTime(veh) > 0):
                reward -= 0.5

        return float(reward)

    def select_action(self, state, traci_instance=None):
        """
        ε-greedy action selection.
        Falls back to max-pressure if Q-values are too uniform.
        """
        if random.random() < self.epsilon:
            return random.randint(0, N_PHASES - 1)
        with torch.no_grad():
            t = torch.FloatTensor(state).unsqueeze(0)
            q_vals = self.policy_net(t).squeeze()
            q_range = float(q_vals.max() - q_vals.min())
            if q_range < 0.01 and traci_instance is not None:
                pressures = {p: compute_phase_pressure(traci_instance, p)
                             for p in range(N_PHASES)}
                return max(pressures, key=pressures.get)
            noise = torch.randn_like(q_vals) * 1e-6
            return int((q_vals + noise).argmax().item())

    def store(self, state, action, reward, next_state, done):
        """Add transition to replay buffer."""
        self.memory.append((state, action, reward, next_state, float(done)))

    def train_step(self):
        """
        Sample minibatch and update policy network.
        Per paper Algorithm 2: DQN update with target network.
        """
        if len(self.memory) < self.batch_size:
            return None

        batch = random.sample(self.memory, self.batch_size)
        states, actions, rewards, next_states, dones = zip(*batch)

        s  = torch.FloatTensor(np.array(states))
        a  = torch.LongTensor(actions).unsqueeze(1)
        r  = torch.FloatTensor(rewards)
        ns = torch.FloatTensor(np.array(next_states))
        d  = torch.FloatTensor(dones)

        # Q(s, a) from policy network
        q_current = self.policy_net(s).gather(1, a).squeeze()

        # Target: r + γ * max_a' Q_target(s', a')
        with torch.no_grad():
            q_next  = self.target_net(ns).max(1)[0]
            q_target = r + self.gamma * q_next * (1 - d)

        loss = self.loss_fn(q_current, q_target)
        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.policy_net.parameters(), 1.0)
        self.optimizer.step()

        # Decay epsilon
        self.epsilon = max(
            self.epsilon_min,
            self.epsilon * self.epsilon_decay
        )

        # Periodically sync target network
        self.steps += 1
        if self.steps % self.target_update == 0:
            self.target_net.load_state_dict(
                self.policy_net.state_dict()
            )

        return float(loss.item())

    def save(self, path):
        torch.save({
            "policy_net": self.policy_net.state_dict(),
            "target_net": self.target_net.state_dict(),
            "epsilon":    self.epsilon,
            "steps":      self.steps,
        }, path)
        print(f"[PressLight-DQN] Saved → {path}")

    def load(self, path):
        ckpt = torch.load(path, map_location="cpu")
        self.policy_net.load_state_dict(ckpt["policy_net"])
        self.target_net.load_state_dict(ckpt["target_net"])
        self.epsilon = ckpt["epsilon"]
        self.steps   = ckpt["steps"]
        self.policy_net.eval()
        print(f"[PressLight-DQN] Loaded ← {path}")