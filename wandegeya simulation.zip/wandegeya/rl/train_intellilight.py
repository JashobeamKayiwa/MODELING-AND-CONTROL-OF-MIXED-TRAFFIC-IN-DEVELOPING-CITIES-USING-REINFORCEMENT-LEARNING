"""
train_intellilight.py
════════════════════════════════════════════════════════════════
Standalone training script for IntelliLight-DQN.

Usage:
    python3 rl/train_intellilight.py --episodes 30 --scenario peak
    python3 rl/train_intellilight.py --episodes 30 --scenario peak --gui
"""

import os, sys, csv, argparse
from datetime import datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from wandegeya_env import WandegeyaEnv, MIN_GREEN
from intellilight   import IntelliLightAgent, STATE_DIM, N_PHASES

try:
    import traci
except ImportError:
    print("traci not found."); sys.exit(1)


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--episodes", type=int, default=30)
    p.add_argument("--scenario", default="peak", choices=["low","medium","peak"])
    p.add_argument("--gui",      action="store_true")
    p.add_argument("--seed",     type=int, default=42)
    return p.parse_args()


def collect_metrics(traci, env):
    queues = env.get_queue_lengths()
    counts = env.get_vehicle_type_counts()
    return {
        "avg_queue":  sum(queues.values()) / len(queues),
        "total_wait": sum(traci.vehicle.getWaitingTime(v) for v in traci.vehicle.getIDList()),
        "n_vehicles": traci.simulation.getMinExpectedNumber(),
        "throughput": traci.simulation.getArrivedNumber(),
        **counts,
    }


# ── Fixed-time baseline ──────────────────────────────────────
def run_fixed_time(scenario, gui=False, seed=42):
    print("\n" + "═"*55)
    print("  FIXED-TIME BASELINE")
    print("═"*55)
    env = WandegeyaEnv(scenario=scenario, gui=gui, seed=seed)
    _, _ = env.reset()
    metrics, step = [], 0
    while True:
        _, reward, done, _, _ = env.step(0)
        m = collect_metrics(traci, env)
        m.update({"step": step, "reward": reward})
        metrics.append(m)
        step += 1
        if step % 50 == 0:
            print(f"  step={step:4d} | queue={m['avg_queue']:.2f} | "
                  f"boda={m['boda_boda']} taxi={m['taxi_minibus']} "
                  f"car={m['private_car']} truck={m['truck']} "
                  f"amb={m['ambulance']} convoy={m['convoy_lead']}")
        if done: break
    env.close()
    return metrics


# ── DQN training ─────────────────────────────────────────────
def train_dqn(scenario, n_episodes, gui=False, seed=42):
    print("\n" + "═"*55)
    print(f"  INTELLILIGHT-DQN TRAINING — {n_episodes} episodes")
    print("═"*55)

    try:
        import torch
    except ImportError:
        print("  ✗ PyTorch not installed. Run: pip install torch"); return None

    agent = IntelliLightAgent(
        lr=1e-3, gamma=0.95,
        epsilon=1.0, epsilon_min=0.05, epsilon_decay=0.9995,
        batch_size=32, memory_size=5000, target_update=20,
    )
    n_params = sum(p.numel() for p in agent.policy_net.parameters())
    print(f"  Network params: {n_params} | State dim: {STATE_DIM} | Actions: {N_PHASES}")
    print(f"  State includes: queue, count, wait, speed per lane + phase + duration + priority\n")
    print(f"  {'Ep':>4}  {'Reward':>10}  {'AvgQueue':>9}  "
          f"{'AvgWait':>8}  {'Loss':>8}  {'ε':>6}  Signal")
    print("  " + "─"*60)

    all_summaries, all_losses = [], []

    for ep in range(1, n_episodes + 1):
        env = WandegeyaEnv(scenario=scenario, gui=False, seed=seed + ep)
        _, _ = env.reset()
        agent.reset_episode()
        state = agent.get_state(traci)

        ep_reward, ep_losses, ep_queues, ep_waits = 0.0, [], [], []
        step = 0

        while True:
            action = agent.select_action(state)
            _, _, done, _, _ = env.step(action)

            # Update phase tracking before getting next state
            agent.update_phase(action, MIN_GREEN)

            next_state = agent.get_state(traci)
            reward     = agent.compute_reward(traci)   # no action needed

            agent.store(state, action, reward, next_state, float(done))
            loss = agent.train_step()
            if loss:
                ep_losses.append(loss)
                all_losses.append(loss)

            m = collect_metrics(traci, env)
            ep_queues.append(m["avg_queue"])
            ep_waits.append(m["total_wait"] / max(m["n_vehicles"], 1))

            state = next_state; ep_reward += reward; step += 1
            if done: break

        env.close()

        avg_loss  = sum(ep_losses) / max(len(ep_losses), 1)
        avg_queue = sum(ep_queues) / max(len(ep_queues), 1)
        avg_wait  = sum(ep_waits)  / max(len(ep_waits),  1)
        all_summaries.append({"ep":ep,"reward":ep_reward,"avg_queue":avg_queue,
                               "avg_wait":avg_wait,"avg_loss":avg_loss,"epsilon":agent.epsilon})
        signal = _learning_signal(all_summaries, all_losses)
        print(f"  {ep:>4}  {ep_reward:>10.1f}  {avg_queue:>9.2f}  "
              f"{avg_wait:>8.2f}  {avg_loss:>8.4f}  {agent.epsilon:>6.3f}  {signal}")

    _print_learning_curve(all_summaries)
    os.makedirs("output", exist_ok=True)
    agent.save("output/intellilight_dqn.pt")
    return agent


def _learning_signal(summaries, losses):
    if len(summaries) < 4: return "warming up..."
    rewards = [s["reward"] for s in summaries]
    n = len(rewards)
    first  = sum(rewards[:n//2]) / (n//2)
    second = sum(rewards[n//2:]) / (n - n//2)
    loss_ok = len(losses) > 20 and sum(losses[-10:])/10 < sum(losses[:10])/10
    if second > first and loss_ok: return "✓ learning"
    elif second > first:           return "~ improving"
    else:                          return "exploring..."


def _print_learning_curve(summaries):
    print("\n  Reward per episode:")
    rewards = [s["reward"] for s in summaries]
    mn, mx = min(rewards), max(rewards)
    for s in summaries:
        pct = (s["reward"] - mn) / max(abs(mx - mn), 1)
        bar = "█" * int(pct * 20)
        up  = "↑" if s["ep"] > 1 and s["reward"] > summaries[s["ep"]-2]["reward"] else " "
        print(f"    Ep {s['ep']:3d}: {s['reward']:10.0f}  |{bar:<20}| {up}")


# ── Evaluation ───────────────────────────────────────────────
def evaluate(agent, scenario, gui=False, seed=42):
    print("\n  Evaluating IntelliLight-DQN (greedy, ε=0)...")
    agent.epsilon = 0.0
    agent.reset_episode()
    env = WandegeyaEnv(scenario=scenario, gui=gui, seed=seed)
    _, _ = env.reset()
    state = agent.get_state(traci)
    metrics, step = [], 0
    while True:
        action = agent.select_action(state)
        _, _, done, _, _ = env.step(action)
        agent.update_phase(action, MIN_GREEN)
        next_state = agent.get_state(traci)
        m = collect_metrics(traci, env)
        m.update({"step": step, "action": action})
        metrics.append(m)
        state = next_state; step += 1
        if step % 50 == 0:
            print(f"  eval step={step:4d} | action={action} | "
                  f"queue={m['avg_queue']:.2f} | "
                  f"boda={m['boda_boda']} taxi={m['taxi_minibus']} "
                  f"car={m['private_car']} amb={m['ambulance']}")
        if done: break
    env.close()
    return metrics


def save_results(ft, dqn_eval, scenario):
    os.makedirs("output", exist_ok=True)
    ts   = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = f"output/intellilight_results_{scenario}_{ts}.csv"

    def avg(metrics, key): return sum(m[key] for m in metrics) / len(metrics)

    rows = [
        {"controller":"Fixed-Time",
         "avg_queue": round(avg(ft,"avg_queue"),2),
         "avg_wait":  round(avg(ft,"total_wait"),1),
         "throughput":sum(m["throughput"] for m in ft)},
    ]
    if dqn_eval:
        rows.append({"controller":"IntelliLight-DQN",
                     "avg_queue": round(avg(dqn_eval,"avg_queue"),2),
                     "avg_wait":  round(avg(dqn_eval,"total_wait"),1),
                     "throughput":sum(m["throughput"] for m in dqn_eval)})

    with open(path,"w",newline="") as f:
        w = csv.DictWriter(f, fieldnames=rows[0].keys())
        w.writeheader(); w.writerows(rows)

    print("\n" + "═"*55)
    print("  INTELLILIGHT RESULTS")
    print("═"*55)
    print(f"  {'Controller':<22} {'AvgQueue':>9} {'AvgWait':>9} {'Throughput':>11}")
    print("  " + "─"*52)
    baseline_q = rows[0]["avg_queue"]; baseline_w = rows[0]["avg_wait"]
    for r in rows:
        tag = ""
        if r["controller"] != "Fixed-Time":
            qi = (baseline_q - r["avg_queue"]) / max(baseline_q,0.01) * 100
            wi = (baseline_w - r["avg_wait"])  / max(baseline_w,0.01) * 100
            tag = f"  ↓q {qi:.1f}%  ↓w {wi:.1f}%"
        print(f"  {r['controller']:<22} {r['avg_queue']:>9.2f} "
              f"{r['avg_wait']:>9.1f} {r['throughput']:>11}{tag}")
    print(f"\n  Saved → {path}")


def main():
    args = parse_args()
    print(f"\n  Scenario: {args.scenario} | Episodes: {args.episodes}")

    ft_metrics  = run_fixed_time(args.scenario, seed=args.seed)
    agent       = train_dqn(args.scenario, args.episodes,
                            gui=args.gui, seed=args.seed)
    dqn_metrics = evaluate(agent, args.scenario,
                           gui=args.gui, seed=args.seed) if agent else None
    save_results(ft_metrics, dqn_metrics, args.scenario)


if __name__ == "__main__":
    main()