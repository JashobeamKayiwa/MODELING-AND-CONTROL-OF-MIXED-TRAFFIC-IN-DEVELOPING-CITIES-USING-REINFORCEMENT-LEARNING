"""
intellilight.py
════════════════════════════════════════════════════════════════
Faithful implementation of IntelliLight for Wandegeya Intersection.

Reference:
  Wei, H., Zheng, G., Yao, H., & Li, Z. (2018).
  IntelliLight: A Reinforcement Learning Approach for Intelligent
  Traffic Light Control.
  KDD 2018. DOI: 10.1145/3219819.3220096

Key differences from PressLight:
─────────────────────────────────────────────────────────────
  IntelliLight uses a richer state representation:
    - Queue length per lane
    - Number of vehicles per lane
    - Waiting time per lane
    - Current phase (one-hot)
    - Phase duration so far

  Reward (per paper Eq. 1):
    r = w1 * ΔQueue + w2 * ΔDelay + w3 * ΔWait + w4 * ΔThroughput
    where Δ = change from previous step (improvement = positive)

  Network:
    - Separate feature extractors per lane
    - Concatenated into a shared representation
    - Outputs Q-value per phase

  This makes IntelliLight more sensitive to spatial-temporal
  patterns than PressLight's pure pressure signal.
─────────────────────────────────────────────────────────────
"""

import random
import numpy as np
from collections import deque

try:
    import torch
    import torch.nn as nn
    import torch.optim as optim
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False
    print("[IntelliLight] torch not found. Install with: pip install torch")

# ════════════════════════════════════════════════════════════════
#  LANE AND PHASE DEFINITIONS
# ════════════════════════════════════════════════════════════════

INBOUND_LANES = [
    "N_in_0", "N_in_1",
    "S_in_0", "S_in_1",
    "W_in_0", "W_in_1",
    "E_in_0", "E_in_1",
]
N_LANES   = len(INBOUND_LANES)   # 8
N_PHASES  = 4

# Max values for normalisation
MAX_QUEUE    = 30.0   # vehicles
MAX_VEHICLES = 40.0   # vehicles
MAX_WAIT     = 180.0  # seconds
MAX_DURATION = 60.0   # seconds

PRIORITY_TYPES = {"ambulance", "convoy_lead", "convoy_follow"}

# Reward weights (paper Table 2)
W_QUEUE      = -0.25
W_DELAY      = -0.25
W_WAIT       = -0.25
W_THROUGHPUT =  0.25


# ════════════════════════════════════════════════════════════════
#  STATE EXTRACTION  (paper Section 3.1)
# ════════════════════════════════════════════════════════════════

def get_lane_features(traci, lane_id):
    """
    Per-lane feature vector (paper Section 3.1):
      [0] queue_length    — halting vehicles, normalised
      [1] vehicle_count   — all vehicles on lane, normalised
      [2] mean_wait       — average waiting time, normalised
      [3] mean_speed      — average speed, normalised
    Returns shape (4,)
    """
    # Queue (halting vehicles)
    queue = traci.lane.getLastStepHaltingNumber(lane_id)

    # Total vehicles
    n_vehs = traci.lane.getLastStepVehicleNumber(lane_id)

    # Mean waiting time
    veh_ids = traci.lane.getLastStepVehicleIDs(lane_id)
    if veh_ids:
        wait = sum(traci.vehicle.getWaitingTime(v) for v in veh_ids) / len(veh_ids)
        speed = sum(traci.vehicle.getSpeed(v) for v in veh_ids) / len(veh_ids)
    else:
        wait  = 0.0
        speed = traci.lane.getMaxSpeed(lane_id)

    return np.array([
        min(queue / MAX_QUEUE,    1.0),
        min(n_vehs / MAX_VEHICLES, 1.0),
        min(wait  / MAX_WAIT,     1.0),
        min(speed / traci.lane.getMaxSpeed(lane_id), 1.0),
    ], dtype=np.float32)


def get_state(traci, current_phase, phase_duration):
    """
    Full IntelliLight state (paper Section 3.1):
      - Lane features for all 8 inbound lanes: 8 × 4 = 32 dims
      - Current phase one-hot: 4 dims
      - Phase duration normalised: 1 dim
      - Priority vehicle flags: 2 dims
    Total: 39 dims
    """
    # Lane features
    lane_feats = np.concatenate([
        get_lane_features(traci, lane)
        for lane in INBOUND_LANES
    ])  # shape (32,)

    # Phase one-hot
    phase_onehot = np.zeros(N_PHASES, dtype=np.float32)
    phase_onehot[current_phase] = 1.0

    # Phase duration
    duration_norm = np.array(
        [min(phase_duration / MAX_DURATION, 1.0)],
        dtype=np.float32
    )

    # Priority vehicle presence
    def priority_on(lanes):
        for lane in lanes:
            for veh in traci.lane.getLastStepVehicleIDs(lane):
                if traci.vehicle.getTypeID(veh) in PRIORITY_TYPES:
                    return 1.0
        return 0.0

    priority = np.array([
        priority_on(["N_in_0","N_in_1","S_in_0","S_in_1"]),
        priority_on(["W_in_0","W_in_1","E_in_0","E_in_1"]),
    ], dtype=np.float32)

    return np.concatenate([lane_feats, phase_onehot, duration_norm, priority])


STATE_DIM = N_LANES * 4 + N_PHASES + 1 + 2  # = 39


# ════════════════════════════════════════════════════════════════
#  REWARD  (paper Eq. 1)
# ════════════════════════════════════════════════════════════════

def compute_reward(traci, prev_metrics):
    """
    r = w1*ΔQueue + w2*ΔDelay + w3*ΔWait + w4*ΔThroughput

    Returns (reward, current_metrics) so metrics can be passed
    as prev_metrics on the next step.
    """
    # Current metrics
    total_queue = sum(
        traci.lane.getLastStepHaltingNumber(l) for l in INBOUND_LANES
    )
    total_vehicles = traci.simulation.getMinExpectedNumber()

    # Waiting time: sum across all active vehicles
    total_wait = sum(
        traci.vehicle.getWaitingTime(v)
        for v in traci.vehicle.getIDList()
    )

    # Throughput: vehicles that arrived this step
    throughput = traci.simulation.getArrivedNumber()

    # Priority vehicle penalty
    priority_penalty = sum(
        1.0 for v in traci.vehicle.getIDList()
        if traci.vehicle.getTypeID(v) in PRIORITY_TYPES
        and traci.vehicle.getWaitingTime(v) > 0
    ) * 5.0

    current = {
        "queue":      total_queue,
        "vehicles":   total_vehicles,
        "wait":       total_wait,
        "throughput": throughput,
    }

    if prev_metrics is None:
        return 0.0, current

    # Δ = improvement (positive = better)
    delta_queue      = prev_metrics["queue"]      - current["queue"]       # less queue = better
    delta_wait       = prev_metrics["wait"]        - current["wait"]        # less wait = better
    delta_throughput = current["throughput"]       - 0                      # more throughput = better
    # Delay: approximate as wait / vehicles
    prev_delay = (prev_metrics["wait"] / max(prev_metrics["vehicles"], 1))
    curr_delay = (current["wait"]       / max(current["vehicles"],     1))
    delta_delay = prev_delay - curr_delay

    reward = (
        W_QUEUE      * (-delta_queue)      +   # penalise queue increase
        W_DELAY      * (-delta_delay)      +   # penalise delay increase
        W_WAIT       * (-delta_wait / 100) +   # penalise wait increase
        W_THROUGHPUT * delta_throughput    -   # reward throughput
        priority_penalty
    )

    return float(reward), current


# ════════════════════════════════════════════════════════════════
#  INTELLILIGHT NETWORK  (paper Fig. 2)
# ════════════════════════════════════════════════════════════════

if TORCH_AVAILABLE:
    class IntelliLightNetwork(nn.Module):
        """
        IntelliLight DQN network (paper Fig. 2).

        Architecture:
          - Per-lane feature extractors (shared weights across lanes)
          - Concatenated lane embeddings + phase/duration/priority
          - Fully connected layers → Q-values per phase

        Input:  state vector, shape (STATE_DIM,) = (39,)
        Output: Q-values, shape (N_PHASES,) = (4,)
        """

        def __init__(
            self,
            state_dim  = STATE_DIM,
            hidden_dim = 64,
            output_dim = N_PHASES,
        ):
            super().__init__()

            # Lane feature encoder (processes 4 features per lane)
            # Shared across all 8 lanes (paper uses shared weights)
            self.lane_encoder = nn.Sequential(
                nn.Linear(4, 16),
                nn.ReLU(),
                nn.Linear(16, 8),
                nn.ReLU(),
            )

            # Combined network
            # Input: 8 lanes × 8 lane embedding + 4 phase + 1 duration + 2 priority = 71
            combined_dim = N_LANES * 8 + N_PHASES + 1 + 2
            self.combined = nn.Sequential(
                nn.Linear(combined_dim, hidden_dim),
                nn.ReLU(),
                nn.Linear(hidden_dim, hidden_dim),
                nn.ReLU(),
                nn.Linear(hidden_dim, output_dim),
            )

        def forward(self, x):
            """
            x shape: (batch, STATE_DIM)
            Lane features are first 32 dims, rest are phase/duration/priority.
            """
            # Split lane features from the rest
            lane_feats = x[:, :N_LANES * 4]          # (batch, 32)
            other      = x[:, N_LANES * 4:]           # (batch, 7)

            # Encode each lane's 4 features independently (shared encoder)
            batch = x.shape[0]
            lane_feats = lane_feats.view(batch, N_LANES, 4)  # (batch, 8, 4)
            lane_embs  = self.lane_encoder(lane_feats)        # (batch, 8, 8)
            lane_embs  = lane_embs.view(batch, -1)            # (batch, 64)

            # Combine and output Q-values
            combined = torch.cat([lane_embs, other], dim=1)   # (batch, 71)
            return self.combined(combined)


# ════════════════════════════════════════════════════════════════
#  IntelliLightAgent
# ════════════════════════════════════════════════════════════════

class IntelliLightAgent:
    """
    IntelliLight DQN agent (faithful to the paper).

    State  : 39-dim spatial-temporal representation
    Action : phase index ∈ {0,1,2,3}
    Reward : weighted sum of ΔQueue + ΔDelay + ΔWait + ΔThroughput
    """

    def __init__(
        self,
        lr            = 1e-3,
        gamma         = 0.95,
        epsilon       = 1.0,
        epsilon_min   = 0.05,
        epsilon_decay = 0.9995,
        batch_size    = 32,
        memory_size   = 5000,
        target_update = 20,
    ):
        if not TORCH_AVAILABLE:
            raise ImportError("torch required. pip install torch")

        self.name          = "IntelliLight-DQN"
        self.gamma         = gamma
        self.epsilon       = epsilon
        self.epsilon_min   = epsilon_min
        self.epsilon_decay = epsilon_decay
        self.batch_size    = batch_size
        self.target_update = target_update
        self.steps         = 0

        # Phase tracking for state construction
        self.current_phase    = 0
        self.phase_duration   = 0
        self.prev_metrics     = None

        self.memory = deque(maxlen=memory_size)

        self.policy_net = IntelliLightNetwork()
        self.target_net = IntelliLightNetwork()
        self.target_net.load_state_dict(self.policy_net.state_dict())
        self.target_net.eval()

        self.optimizer = optim.Adam(
            self.policy_net.parameters(), lr=lr
        )
        self.loss_fn = nn.MSELoss()

    def get_state(self, traci):
        """39-dim spatial-temporal state vector."""
        return get_state(traci, self.current_phase, self.phase_duration)

    def compute_reward(self, traci, action=None):
        """Weighted multi-objective reward, updates internal metrics.
        action parameter accepted but not used (for API consistency with PressLight)."""
        reward, self.prev_metrics = compute_reward(traci, self.prev_metrics)
        return reward

    def select_action(self, state):
        """ε-greedy action selection with random tiebreaking."""
        if random.random() < self.epsilon:
            return random.randint(0, N_PHASES - 1)
        with torch.no_grad():
            t = torch.FloatTensor(state).unsqueeze(0)
            q_vals = self.policy_net(t).squeeze()
            noise = torch.randn_like(q_vals) * 1e-6
            return int((q_vals + noise).argmax().item())

    def update_phase(self, action, steps_taken):
        """Call after env.step() to track phase and duration."""
        if action != self.current_phase:
            self.current_phase  = action
            self.phase_duration = steps_taken
        else:
            self.phase_duration += steps_taken

    def store(self, state, action, reward, next_state, done):
        self.memory.append((state, action, reward, next_state, float(done)))

    def train_step(self):
        """DQN update step with experience replay."""
        if len(self.memory) < self.batch_size:
            return None

        batch = random.sample(self.memory, self.batch_size)
        states, actions, rewards, next_states, dones = zip(*batch)

        s  = torch.FloatTensor(np.array(states))
        a  = torch.LongTensor(actions).unsqueeze(1)
        r  = torch.FloatTensor(rewards)
        ns = torch.FloatTensor(np.array(next_states))
        d  = torch.FloatTensor(dones)

        q_current = self.policy_net(s).gather(1, a).squeeze()

        with torch.no_grad():
            q_next   = self.target_net(ns).max(1)[0]
            q_target = r + self.gamma * q_next * (1 - d)

        loss = self.loss_fn(q_current, q_target)
        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.policy_net.parameters(), 1.0)
        self.optimizer.step()

        self.epsilon = max(self.epsilon_min, self.epsilon * self.epsilon_decay)

        self.steps += 1
        if self.steps % self.target_update == 0:
            self.target_net.load_state_dict(self.policy_net.state_dict())

        return float(loss.item())

    def reset_episode(self):
        """Reset episode-level tracking."""
        self.current_phase  = 0
        self.phase_duration = 0
        self.prev_metrics   = None

    def save(self, path):
        torch.save({
            "policy_net": self.policy_net.state_dict(),
            "target_net": self.target_net.state_dict(),
            "epsilon":    self.epsilon,
            "steps":      self.steps,
        }, path)
        print(f"[IntelliLight] Saved → {path}")

    def load(self, path):
        ckpt = torch.load(path, map_location="cpu")
        self.policy_net.load_state_dict(ckpt["policy_net"])
        self.target_net.load_state_dict(ckpt["target_net"])
        self.epsilon = ckpt["epsilon"]
        self.steps   = ckpt["steps"]
        self.policy_net.eval()
        print(f"[IntelliLight] Loaded ← {path}")