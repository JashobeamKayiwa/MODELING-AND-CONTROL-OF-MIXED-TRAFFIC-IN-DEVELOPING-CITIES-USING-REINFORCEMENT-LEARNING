# Wandegeya Intersection — SUMO RL Traffic Project
**Makerere University, Group 19 — Final Year Project**

## Project Structure
```
wandegeya/
├── setup.sh                    ← Run this first on your machine
├── network/
│   ├── wandegeya.net.xml       ← SUMO road network (Bombo Rd x Makerere Hill Rd)
│   └── detectors.add.xml       ← Virtual sensors (induction loops + queue detectors)
├── routes/
│   ├── vehicle_types.add.xml   ← Boda boda, taxi, car, truck definitions
│   ├── generate_routes.py      ← Generates traffic demand for any scenario
│   ├── wandegeya_peak.rou.xml  ← Peak demand: 1400 veh/hr
│   ├── wandegeya_medium.rou.xml← Medium demand: 800 veh/hr
│   └── wandegeya_low.rou.xml   ← Low demand: 340 veh/hr
├── config/
│   ├── wandegeya_peak.sumocfg
│   ├── wandegeya_medium.sumocfg
│   └── wandegeya_low.sumocfg
├── output/                     ← Simulation results go here
└── rl/                         ← RL agent code goes here (next phase)
```

## Running the Simulation

### Test run (5 minutes, peak scenario):
```bash
sumo --net-file network/wandegeya.net.xml \
     --route-files routes/wandegeya_peak.rou.xml \
     --additional-files routes/vehicle_types.add.xml,network/detectors.add.xml \
     --begin 0 --end 300 --step-length 1 \
     --tripinfo-output output/tripinfo.xml
```

### Visual run (with GUI):
```bash
sumo-gui --net-file network/wandegeya.net.xml \
         --route-files routes/wandegeya_peak.rou.xml \
         --additional-files routes/vehicle_types.add.xml,network/detectors.add.xml
```

### Full 1-hour simulation:
```bash
sumo -c config/wandegeya_peak.sumocfg
```

### Regenerate routes for a different scenario:
```bash
python3 routes/generate_routes.py --scenario medium --duration 3600 --seed 42
```

## Traffic Signal (Fixed-Time Baseline)
| Phase | Movement | Duration |
|-------|----------|----------|
| 0 | Bombo Rd N↔S Green | 35s |
| 1 | All Yellow | 4s |
| 2 | Makerere Hill Rd E↔W Green | 30s |
| 3 | All Yellow | 4s |
| **Total cycle** | | **73s** |

## Vehicle Composition
| Type | Proportion | Max Speed |
|------|-----------|-----------|
| Boda Boda | 50% | 45 km/h |
| Taxi/Minibus | 20% | 35 km/h |
| Private Car | 25% | 50 km/h |
| Truck | 5% | 30 km/h |

## Next Steps
- [ ] Phase 2: RL Environment (TraCI + Python)
- [ ] Phase 3: PressLight implementation
- [ ] Phase 4: IntelliLight implementation
- [ ] Phase 5: Evaluation vs fixed-time baseline
